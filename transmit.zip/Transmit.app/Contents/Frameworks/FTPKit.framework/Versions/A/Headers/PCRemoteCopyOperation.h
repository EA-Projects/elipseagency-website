#import "PCRemoteUploadOperation.h"

@class PCRemoteFileNode;

@interface PCRemoteCopyOperation : PCRemoteUploadOperation

@end
