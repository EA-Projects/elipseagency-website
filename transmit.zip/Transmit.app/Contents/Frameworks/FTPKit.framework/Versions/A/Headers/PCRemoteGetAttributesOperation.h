#import "PCRemoteOperation.h"

@interface PCRemoteGetAttributesOperation : PCRemoteOperation

@property (assign, getter=isTransient) BOOL transient;

@end
