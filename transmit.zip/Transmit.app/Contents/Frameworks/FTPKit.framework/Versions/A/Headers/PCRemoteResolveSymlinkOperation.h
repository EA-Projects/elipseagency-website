#import "PCRemoteOperation.h"

@class PCRemoteAliasNode;

@interface PCRemoteResolveSymlinkOperation : PCRemoteOperation

@end
