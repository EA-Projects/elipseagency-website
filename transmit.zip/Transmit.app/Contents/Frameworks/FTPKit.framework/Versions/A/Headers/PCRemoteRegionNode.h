//
//  PCRemoteRegionNode.h
//  FTPKit
//
//  Created by Will Cosgrove on 8/17/16.
//  Copyright © 2016 Panic Inc. All rights reserved.
//

#import <FTPKit/FTPKit.h>

FTPKIT_EXTERN NSString * const PCTypeIdentifierSwiftRegion;

@interface PCRemoteRegionNode : PCRemoteFolderNode

@end
