#import "PCFSOperation.h"

@interface PCLocalChangeAttributesOperation : PCFSOperation <PCSpooledProcessingOperation>

@end
